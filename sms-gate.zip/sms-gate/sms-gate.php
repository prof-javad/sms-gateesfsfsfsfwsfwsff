<?php
/**
 * Plugin Name: SMS Gate
 * Plugin URI: https://sms-gate.app/
 * Description: Send SMS using SMS-Gate mobile application.
 * Version: 0.1.1
 * Author: James
 * License: GPL2
 * Text Domain: sms-gate
 * Domain Path: /languages
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'SMSGATE_VERSION', '0.1.1' );
define( 'SMSGATE_FILE', __FILE__ );
define( 'SMSGATE_PATH', plugin_dir_path( __FILE__ ) );
define( 'SMSGATE_URL', plugin_dir_url( __FILE__ ) );
define( 'SMSGATE_BASENAME', plugin_basename( __FILE__ ) );

// Load the autoloader.
require_once SMSGATE_PATH . 'includes/class-loader.php';

/**
 * Initialize the plugin.
 */
function smsgate_init() {
	$loader = new SMSGate_Loader();
	$loader->register();
}
add_action( 'plugins_loaded', 'smsgate_init' );

// Register activation and deactivation hooks.
register_activation_hook( __FILE__, array( 'SMSGate_Loader', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'SMSGate_Loader', 'deactivate' ) );