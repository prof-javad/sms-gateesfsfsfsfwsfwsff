/**
 * Admin JavaScript for SMS Gate.
 *
 * @package SMSGate
 */

jQuery( function( $ ) {
	'use strict';

	// Test SMS functionality.
	$( '#smsgate-send' ).on( 'click', function( e ) {
		e.preventDefault();

		var $result = $( '#smsgate-result' );
		$result.html( 'Sending...' );

		$.post(
			smsgate_ajax.ajax_url,
			{
				action: 'smsgate_send_test',
				nonce: smsgate_ajax.nonce,
				phone: $( '#smsgate_phone' ).val(),
				message: $( '#smsgate_message' ).val()
			},
			function( response ) {
				if ( response.success ) {
					$result.html( JSON.stringify( response.data, null, 4 ) );
				} else {
					$result.html( 'Error: ' + response.data );
				}
			}
		).fail( function() {
			$result.html( 'Request failed' );
		} );
	} );

	// Form validation.
	$( 'form' ).on( 'submit', function( e ) {
		var valid = true;
		var required = $( this ).find( '.required' );

		required.each( function() {
			var $field = $( this );
			var value = $field.val().trim();

			if ( '' === value ) {
				$field.addClass( 'error' );
				valid = false;
			} else {
				$field.removeClass( 'error' );
			}
		} );

		if ( ! valid ) {
			e.preventDefault();
			alert( smsgate_ajax.required_fields || 'Please fill in all required fields.' );
		}
	} );

	// Validation styling.
	$( '.required' ).on( 'change keyup', function() {
		var $field = $( this );
		if ( '' !== $field.val().trim() ) {
			$field.removeClass( 'error' );
		}
	} );
} );