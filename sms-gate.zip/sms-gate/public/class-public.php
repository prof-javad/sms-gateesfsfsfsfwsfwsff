<?php
/**
 * Public facing functionality.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Public
 */
class SMSGate_Public {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init_hooks();
	}

	/**
	 * Initialize public hooks.
	 */
	private function init_hooks() {
		// Public hooks placeholder.
	}
}