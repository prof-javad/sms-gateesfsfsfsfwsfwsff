<?php
/**
 * SMS service class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_SMS_Service
 * 
 * Handles all SMS-specific business logic.
 * This class is provider-aware and knows about SMS-Gate API structure.
 */
class SMSGate_SMS_Service {

	/**
	 * API client instance.
	 *
	 * @var SMSGate_API
	 */
	private $api;

	/**
	 * Settings instance.
	 *
	 * @var SMSGate_Settings
	 */
	private $settings;

	/**
	 * Logger instance.
	 *
	 * @var SMSGate_Logger
	 */
	private $logger;

	/**
	 * API endpoint for messages.
	 *
	 * @var string
	 */
	const ENDPOINT_MESSAGES = '/messages';

	/**
	 * API endpoint for device status.
	 *
	 * @var string
	 */
	const ENDPOINT_DEVICE_STATUS = '/devices/%s/status';

	/**
	 * API endpoint for balance.
	 *
	 * @var string
	 */
	const ENDPOINT_BALANCE = '/balance';

	/**
	 * Constructor.
	 *
	 * @param SMSGate_API      $api      API client instance.
	 * @param SMSGate_Settings $settings Settings instance.
	 */
	public function __construct( $api, $settings ) {
		$this->api      = $api;
		$this->settings = $settings;
		$this->logger   = new SMSGate_Logger();

		// Configure API client.
		$this->configure_api_client();
	}

	/**
	 * Configure the API client with settings.
	 */
	private function configure_api_client() {
		$api_url = $this->settings->get_api_url();
		$api_key = $this->settings->get_api_key();

		// Set timeout.
		$this->api->set_timeout( $this->settings->get_timeout() );

		// Set authentication header.
		if ( ! empty( $api_key ) ) {
			$this->api->add_header(
				'Authorization',
				'Basic ' . base64_encode( $api_key . ':' )
			);
		}

		// Set common headers.
		$this->api->set_headers( array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
		) );
	}

	/**
	 * Send SMS message.
	 *
	 * @param string $phone   Phone number.
	 * @param string $message Message text.
	 * @return array Standardized response array.
	 */
	public function send( $phone, $message ) {
		if ( ! $this->settings->is_configured() ) {
			$this->logger->error( 'SMS service not configured' );
			return array(
				'success'     => false,
				'provider'    => 'SMS-Gate',
				'response'    => null,
				'error'       => __( 'SMS service not configured', 'sms-gate' ),
				'error_code'  => 'NOT_CONFIGURED',
			);
		}

		// Validate inputs.
		$phone = SMSGate_Helper::sanitize_phone( $phone );
		$message = wp_kses_post( $message );

		if ( empty( $phone ) ) {
			$this->logger->error( 'Invalid phone number' );
			return array(
				'success'     => false,
				'provider'    => 'SMS-Gate',
				'response'    => null,
				'error'       => __( 'Invalid phone number', 'sms-gate' ),
				'error_code'  => 'INVALID_PHONE',
			);
		}

		if ( empty( $message ) ) {
			$this->logger->error( 'Empty message' );
			return array(
				'success'     => false,
				'provider'    => 'SMS-Gate',
				'response'    => null,
				'error'       => __( 'Empty message', 'sms-gate' ),
				'error_code'  => 'EMPTY_MESSAGE',
			);
		}

		// Build the request.
		$url = $this->build_messages_url();
		$body = $this->build_sms_body( $phone, $message );

		// Send the request.
		$response = $this->api->post( $url, $body );

		// Check for errors.
		if ( ! $response['success'] ) {
			$error = isset( $response['error'] ) ? $response['error'] : __( 'Unknown error', 'sms-gate' );
			$this->logger->error( 'SMS send failed', array( 'error' => $error ) );
			
			return array(
				'success'     => false,
				'provider'    => 'SMS-Gate',
				'response'    => $response,
				'error'       => $error,
				'error_code'  => isset( $response['decoded_body']['code'] ) ? $response['decoded_body']['code'] : 'UNKNOWN_ERROR',
			);
		}

		return array(
			'success'     => true,
			'provider'    => 'SMS-Gate',
			'response'    => $response,
			'error'       => '',
			'error_code'  => '',
		);
	}

	/**
	 * Get device status.
	 *
	 * @param string $device_id Device ID.
	 * @return array|bool
	 */
	public function get_device_status( $device_id ) {
		if ( empty( $device_id ) ) {
			$this->logger->error( 'Device ID is empty' );
			return false;
		}

		if ( ! $this->settings->is_configured() ) {
			$this->logger->error( 'SMS service not configured' );
			return false;
		}

		$url = $this->build_device_status_url( $device_id );
		$response = $this->api->get( $url );

		if ( ! $response['success'] ) {
			$error = isset( $response['error'] ) ? $response['error'] : __( 'Unknown error', 'sms-gate' );
			$this->logger->error( 'Device status check failed', array( 'error' => $error ) );
			return false;
		}

		return $response;
	}

	/**
	 * Get account balance.
	 *
	 * @return array|bool
	 */
	public function get_balance() {
		if ( ! $this->settings->is_configured() ) {
			$this->logger->error( 'SMS service not configured' );
			return false;
		}

		$url = $this->build_balance_url();
		$response = $this->api->get( $url );

		if ( ! $response['success'] ) {
			$error = isset( $response['error'] ) ? $response['error'] : __( 'Unknown error', 'sms-gate' );
			$this->logger->error( 'Balance check failed', array( 'error' => $error ) );
			return false;
		}

		return $response;
	}

	/**
	 * Build messages endpoint URL.
	 *
	 * @return string
	 */
	private function build_messages_url() {
		return rtrim( $this->settings->get_api_url(), '/' ) . self::ENDPOINT_MESSAGES;
	}

	/**
	 * Build device status endpoint URL.
	 *
	 * @param string $device_id Device ID.
	 * @return string
	 */
	private function build_device_status_url( $device_id ) {
		$endpoint = sprintf( self::ENDPOINT_DEVICE_STATUS, $device_id );
		return rtrim( $this->settings->get_api_url(), '/' ) . $endpoint;
	}

	/**
	 * Build balance endpoint URL.
	 *
	 * @return string
	 */
	private function build_balance_url() {
		return rtrim( $this->settings->get_api_url(), '/' ) . self::ENDPOINT_BALANCE;
	}

	/**
	 * Build SMS request body.
	 *
	 * @param string $phone   Phone number.
	 * @param string $message Message text.
	 * @return array
	 */
	private function build_sms_body( $phone, $message ) {
		$device_id = $this->settings->get_device_id();

		return array(
			'deviceId'     => $device_id,
			'phoneNumbers' => array( $phone ),
			'textMessage'  => array(
				'text' => $message,
			),
		);
	}
}