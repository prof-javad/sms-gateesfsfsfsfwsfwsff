<?php
/**
 * Phone number validation and normalization class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Phone
 * 
 * Handles phone number validation and normalization.
 * Currently supports Iranian mobile numbers only.
 * This class has no knowledge of SMS, APIs, or WooCommerce.
 * 
 * @since 0.1.0
 */
class SMSGate_Phone {

	/**
	 * Country code for Iran.
	 *
	 * @var string
	 */
	const COUNTRY_CODE_IRAN = '98';

	/**
	 * Minimum length of a normalized phone number.
	 *
	 * @var int
	 */
	const MIN_LENGTH = 10;

	/**
	 * Maximum length of a normalized phone number.
	 *
	 * @var int
	 */
	const MAX_LENGTH = 15;

	/**
	 * Valid mobile prefixes for Iran.
	 *
	 * @var array
	 */
	private static $valid_prefixes = array(
		'910', '911', '912', '913', '914', '915', '916', '917', '918', '919',
		'920', '921', '922', '923', '924', '925', '926', '927', '928', '929',
		'930', '931', '932', '933', '934', '935', '936', '937', '938', '939',
		'940', '941', '942', '943', '944', '945', '946', '947', '948', '949',
		'950', '951', '952', '953', '954', '955', '956', '957', '958', '959',
		'990', '991', '992', '993', '994', '995', '996', '997', '998', '999',
	);

	/**
	 * Normalize and validate a phone number.
	 *
	 * @param string $phone Phone number to normalize.
	 * @return string|false Normalized phone number or false if invalid.
	 */
	public static function normalize( $phone ) {
		// Sanitize input.
		$phone = self::sanitize( $phone );

		if ( empty( $phone ) ) {
			return false;
		}

		// Remove all non-digit characters except '+'.
		$phone = preg_replace( '/[^0-9+]/', '', $phone );

		if ( empty( $phone ) ) {
			return false;
		}

		// Normalize to standard format.
		$normalized = self::format( $phone );

		if ( ! $normalized ) {
			return false;
		}

		// Validate the normalized number.
		if ( ! self::is_valid( $normalized ) ) {
			return false;
		}

		return $normalized;
	}

	/**
	 * Validate a phone number.
	 *
	 * @param string $phone Phone number to validate.
	 * @return bool True if valid, false otherwise.
	 */
	public static function is_valid( $phone ) {
		// Sanitize input.
		$phone = self::sanitize( $phone );

		if ( empty( $phone ) ) {
			return false;
		}

		// Remove all non-digit characters.
		$phone = preg_replace( '/[^0-9]/', '', $phone );

		if ( empty( $phone ) ) {
			return false;
		}

		// Check length.
		$length = strlen( $phone );
		if ( $length < self::MIN_LENGTH || $length > self::MAX_LENGTH ) {
			return false;
		}

		// Check country code and extract mobile part.
		$mobile = self::extract_mobile_part( $phone );

		if ( ! $mobile ) {
			return false;
		}

		// Check prefix.
		$prefix = substr( $mobile, 0, 3 );
		if ( ! in_array( $prefix, self::$valid_prefixes, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Format a phone number to standard format.
	 *
	 * @param string $phone Phone number to format.
	 * @return string|false Formatted phone number or false if invalid.
	 */
	public static function format( $phone ) {
		// Sanitize input.
		$phone = self::sanitize( $phone );

		if ( empty( $phone ) ) {
			return false;
		}

		// Remove all non-digit characters.
		$phone = preg_replace( '/[^0-9]/', '', $phone );

		if ( empty( $phone ) ) {
			return false;
		}

		// Remove leading zeros.
		$phone = ltrim( $phone, '0' );

		// Handle different formats.
		$length = strlen( $phone );

		// If it starts with 98, it already has country code.
		if ( strpos( $phone, self::COUNTRY_CODE_IRAN ) === 0 ) {
			// Already in correct format.
			return $phone;
		}

		// If it's 10 digits (0XXXXXXXXX), add country code.
		if ( $length === 10 ) {
			return self::COUNTRY_CODE_IRAN . $phone;
		}

		// If it's 9 digits (XXXXXXXXX), add country code.
		if ( $length === 9 ) {
			return self::COUNTRY_CODE_IRAN . $phone;
		}

		// If it's 11 digits (0XXXXXXXXXX), remove leading zero and add country code.
		if ( $length === 11 && strpos( $phone, '0' ) === 0 ) {
			return self::COUNTRY_CODE_IRAN . substr( $phone, 1 );
		}

		// Invalid format.
		return false;
	}

	/**
	 * Sanitize phone number input.
	 *
	 * @param string $phone Phone number to sanitize.
	 * @return string Sanitized phone number.
	 */
	public static function sanitize( $phone ) {
		if ( ! is_string( $phone ) ) {
			return '';
		}

		// Trim whitespace.
		$phone = trim( $phone );

		// Remove spaces, dashes, dots, parentheses, and other common separators.
		$phone = preg_replace( '/[\s\-\.\(\)]/', '', $phone );

		return $phone;
	}

	/**
	 * Extract mobile part from phone number.
	 *
	 * @param string $phone Phone number.
	 * @return string|false Mobile part or false if invalid.
	 */
	private static function extract_mobile_part( $phone ) {
		$length = strlen( $phone );

		// If starts with 98, remove country code.
		if ( strpos( $phone, self::COUNTRY_CODE_IRAN ) === 0 ) {
			$mobile = substr( $phone, 2 );
			if ( strlen( $mobile ) === 10 ) {
				return $mobile;
			}
			return false;
		}

		// If starts with 0, remove it.
		if ( strpos( $phone, '0' ) === 0 ) {
			$mobile = substr( $phone, 1 );
			if ( strlen( $mobile ) === 10 ) {
				return $mobile;
			}
			return false;
		}

		// If it's already 10 digits.
		if ( $length === 10 ) {
			return $phone;
		}

		return false;
	}

	/**
	 * Get country code from phone number.
	 *
	 * @param string $phone Phone number.
	 * @return string|false Country code or false if invalid.
	 */
	public static function get_country_code( $phone ) {
		$normalized = self::normalize( $phone );

		if ( ! $normalized ) {
			return false;
		}

		// Extract country code (first 2 digits).
		if ( strpos( $normalized, self::COUNTRY_CODE_IRAN ) === 0 ) {
			return self::COUNTRY_CODE_IRAN;
		}

		return false;
	}

	/**
	 * Get the mobile number without country code.
	 *
	 * @param string $phone Phone number.
	 * @return string|false Mobile number without country code or false if invalid.
	 */
	public static function get_mobile_without_country_code( $phone ) {
		$normalized = self::normalize( $phone );

		if ( ! $normalized ) {
			return false;
		}

		if ( strpos( $normalized, self::COUNTRY_CODE_IRAN ) === 0 ) {
			return substr( $normalized, 2 );
		}

		return false;
	}

	/**
	 * Get the mobile number with leading zero (for local format).
	 *
	 * @param string $phone Phone number.
	 * @return string|false Mobile number with leading zero or false if invalid.
	 */
	public static function get_local_format( $phone ) {
		$mobile = self::get_mobile_without_country_code( $phone );

		if ( ! $mobile ) {
			return false;
		}

		return '0' . $mobile;
	}

	/**
	 * Check if phone number is Iranian.
	 *
	 * @param string $phone Phone number.
	 * @return bool True if Iranian, false otherwise.
	 */
	public static function is_iranian( $phone ) {
		$normalized = self::normalize( $phone );

		if ( ! $normalized ) {
			return false;
		}

		return strpos( $normalized, self::COUNTRY_CODE_IRAN ) === 0;
	}

	/**
	 * Get all valid prefixes for Iran.
	 *
	 * @return array List of valid prefixes.
	 */
	public static function get_valid_prefixes() {
		return self::$valid_prefixes;
	}
}