<?php
/**
 * WooCommerce integration class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_WooCommerce
 * 
 * Handles WooCommerce order event detection.
 * This class is responsible for detecting order events and generating standardized payloads.
 * It does NOT send SMS, process templates, or call APIs.
 * 
 * @since 0.1.0
 */
class SMSGate_WooCommerce {

	/**
	 * Order instance.
	 *
	 * @var WC_Order|null
	 */
	private $order = null;

	/**
	 * Event payload.
	 *
	 * @var array
	 */
	private $payload = array();

	/**
	 * Data layer instance.
	 *
	 * @var SMSGate_WooCommerce_Data
	 */
	private $data_layer;

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Initialize data layer.
		$this->data_layer = new SMSGate_WooCommerce_Data();
	}

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	public function is_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Register WooCommerce hooks.
	 */
	public function register_hooks() {
		if ( ! $this->is_active() ) {
			return;
		}

		// Use a single hook for all status changes.
		add_action( 'woocommerce_order_status_changed', array( $this, 'handle_order_status_changed' ), 10, 4 );

		// New order hook.
		add_action( 'woocommerce_new_order', array( $this, 'handle_new_order' ), 10, 1 );
	}

	/**
	 * Handle new order event.
	 *
	 * @param int $order_id Order ID.
	 */
	public function handle_new_order( $order_id ) {
		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		$this->order = $order;
		$this->build_payload( 'new_order' );
	}

	/**
	 * Handle order status change event.
	 *
	 * @param int      $order_id   Order ID.
	 * @param string   $old_status Old status.
	 * @param string   $new_status New status.
	 * @param WC_Order $order      Order object.
	 */
	public function handle_order_status_changed( $order_id, $old_status, $new_status, $order ) {
		// Only process if order is valid.
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		// Only handle specific statuses.
		$allowed_statuses = array( 'processing', 'completed', 'cancelled' );
		
		if ( ! in_array( $new_status, $allowed_statuses, true ) ) {
			return;
		}

		$this->order = $order;
		
		// Get event name from status.
		$event = $this->get_event_from_status( $new_status );

		if ( ! $event ) {
			return;
		}

		$this->build_payload( $event );
	}

	/**
	 * Get event name from order status.
	 *
	 * @param string $status Order status.
	 * @return string|false
	 */
	private function get_event_from_status( $status ) {
		$status_map = array(
			'processing' => 'processing',
			'completed'  => 'completed',
			'cancelled'  => 'cancelled',
		);

		return isset( $status_map[ $status ] ) ? $status_map[ $status ] : false;
	}

	/**
	 * Build standardized event payload.
	 *
	 * @param string $event Event name.
	 */
	private function build_payload( $event ) {
		if ( ! $this->order ) {
			return;
		}

		// Get order data from data layer.
		$order_data_result = $this->data_layer->get_order_data( $this->order );
		$order_data = isset( $order_data_result['data'] ) ? $order_data_result['data'] : array();

		// Build payload.
		$this->payload = array(
			'event'      => $event,
			'order_id'   => $this->order->get_id(),
			'status'     => $this->order->get_status(),
			'timestamp'  => current_time( 'Y-m-d H:i:s' ),
			'order_data' => $order_data,
		);

		// Dispatch the event.
		$this->dispatch_event();
	}

	/**
	 * Dispatch the event using WordPress actions.
	 */
	private function dispatch_event() {
		/**
		 * Fires when an order event occurs.
		 *
		 * @param array $payload Event payload containing order data.
		 */
		do_action( 'smsgate_order_event', $this->payload );
	}

	/**
	 * Get the last event payload.
	 *
	 * @return array
	 */
	public function get_last_payload() {
		return $this->payload;
	}

	/**
	 * Handle order status change (placeholder - backward compatibility).
	 *
	 * @param int    $order_id Order ID.
	 * @param string $old_status Old status.
	 * @param string $new_status New status.
	 * @deprecated Use handle_order_status_changed instead.
	 */
	public function order_status_changed( $order_id, $old_status, $new_status ) {
		// Get order object.
		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		// Use the new handler.
		$this->handle_order_status_changed( $order_id, $old_status, $new_status, $order );
	}
}