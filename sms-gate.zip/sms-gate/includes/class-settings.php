<?php
/**
 * Settings management class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Settings
 */
class SMSGate_Settings {

	/**
	 * Option name for storing all settings.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'smsgate_settings';

	/**
	 * Default settings values.
	 *
	 * @var array
	 */
	private $defaults = array(
		// General settings.
		'api_url'         => 'https://api.sms-gate.app/3rdparty/v1',
		'api_key'         => '',
		'sender_number'   => '',
		'manager_number'  => '',
		'timeout'         => 30,
		'device_id'       => '',

		// Order status settings.
		'enable_new_order'     => 'yes',
		'enable_processing'    => 'yes',
		'enable_completed'     => 'yes',
		'enable_cancelled'     => 'no',

		// Template settings.
		'template_new_order'    => 'Your order {order_id} has been placed successfully. Thank you for your purchase!',
		'template_processing'   => 'Your order {order_id} is being processed.',
		'template_completed'    => 'Your order {order_id} has been completed. Thank you!',
		'template_cancelled'    => 'Your order {order_id} has been cancelled.',
	);

	/**
	 * Get all settings.
	 *
	 * @return array
	 */
	public function get_all() {
		$settings = get_option( self::OPTION_NAME, array() );
		return wp_parse_args( $settings, $this->defaults );
	}

	/**
	 * Get a specific setting.
	 *
	 * @param string $key Setting key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public function get( $key, $default = null ) {
		$settings = $this->get_all();

		if ( isset( $settings[ $key ] ) ) {
			return $settings[ $key ];
		}

		if ( isset( $this->defaults[ $key ] ) ) {
			return $this->defaults[ $key ];
		}

		return $default;
	}

	/**
	 * Get option value.
	 *
	 * @param string $key Option key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public function get_option( $key, $default = null ) {
		return $this->get( $key, $default );
	}

	/**
	 * Set option value.
	 *
	 * @param string $key Option key.
	 * @param mixed  $value Option value.
	 * @return bool
	 */
	public function set_option( $key, $value ) {
		$settings = $this->get_all();
		$settings[ $key ] = $value;
		return update_option( self::OPTION_NAME, $settings );
	}

	/**
	 * Delete option.
	 *
	 * @param string $key Option key.
	 * @return bool
	 */
	public function delete_option( $key ) {
		$settings = $this->get_all();
		
		if ( isset( $settings[ $key ] ) ) {
			unset( $settings[ $key ] );
			return update_option( self::OPTION_NAME, $settings );
		}
		
		return false;
	}

	/**
	 * Check if option exists.
	 *
	 * @param string $key Option key.
	 * @return bool
	 */
	public function has_option( $key ) {
		$settings = $this->get_all();
		return isset( $settings[ $key ] );
	}

	/**
	 * Update settings.
	 *
	 * @param array $settings New settings.
	 * @return bool
	 */
	public function update( $settings ) {
		$current = $this->get_all();
		$updated = array_merge( $current, $settings );

		return update_option( self::OPTION_NAME, $updated );
	}

	/**
	 * Reset settings to defaults.
	 *
	 * @return bool
	 */
	public function reset() {
		return update_option( self::OPTION_NAME, $this->defaults );
	}

	/**
	 * Get default values.
	 *
	 * @return array
	 */
	public function get_defaults() {
		return $this->defaults;
	}

	/**
	 * Get API URL.
	 *
	 * @return string
	 */
	public function get_api_url() {
		return $this->get( 'api_url' );
	}

	/**
	 * Get API Key.
	 *
	 * @return string
	 */
	public function get_api_key() {
		return $this->get( 'api_key' );
	}

	/**
	 * Get sender number.
	 *
	 * @return string
	 */
	public function get_sender_number() {
		return $this->get( 'sender_number' );
	}

	/**
	 * Get manager number.
	 *
	 * @return string
	 */
	public function get_manager_number() {
		return $this->get( 'manager_number' );
	}

	/**
	 * Get timeout.
	 *
	 * @return int
	 */
	public function get_timeout() {
		return absint( $this->get( 'timeout' ) );
	}

	/**
	 * Get device ID.
	 *
	 * @return string
	 */
	public function get_device_id() {
		return $this->get( 'device_id' );
	}

	/**
	 * Check if a status is enabled.
	 *
	 * @param string $status Status key.
	 * @return bool
	 */
	public function is_status_enabled( $status ) {
		$key = 'enable_' . $status;
		return 'yes' === $this->get( $key, 'no' );
	}

	/**
	 * Get template for a status.
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	public function get_template( $status ) {
		$key = 'template_' . $status;
		return $this->get( $key, '' );
	}

	/**
	 * Check if settings are complete.
	 *
	 * @return bool
	 */
	public function is_configured() {
		return ! empty( $this->get_api_url() )
			&& ! empty( $this->get_api_key() )
			&& ! empty( $this->get_sender_number() );
	}

	/**
	 * Get option group name.
	 *
	 * @return string
	 */
	public function get_option_group() {
		return self::OPTION_NAME . '_group';
	}

	/**
	 * Get section names.
	 *
	 * @return array
	 */
	public function get_sections() {
		return array(
			'general'       => __( 'General Settings', 'sms-gate' ),
			'order_status'  => __( 'Order Status Settings', 'sms-gate' ),
			'templates'     => __( 'SMS Templates', 'sms-gate' ),
		);
	}
}