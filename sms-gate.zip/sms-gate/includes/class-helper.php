<?php
/**
 * Helper utilities class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Helper
 */
class SMSGate_Helper {

	/**
	 * Sanitize phone number.
	 *
	 * @param string $phone Phone number.
	 * @return string
	 */
	public static function sanitize_phone( $phone ) {
		return preg_replace( '/[^0-9+]/', '', $phone );
	}

	/**
	 * Truncate message to maximum length.
	 *
	 * @param string $message Message text.
	 * @param int    $max_length Maximum length.
	 * @return string
	 */
	public static function truncate_message( $message, $max_length = 160 ) {
		if ( strlen( $message ) <= $max_length ) {
			return $message;
		}

		return mb_substr( $message, 0, $max_length - 3 ) . '...';
	}

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	public static function is_woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Get plugin option with default value.
	 *
	 * @param string $key Option key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public static function get_option( $key, $default = null ) {
		$value = get_option( 'smsgate_' . $key );

		if ( false === $value ) {
			return $default;
		}

		return $value;
	}
}