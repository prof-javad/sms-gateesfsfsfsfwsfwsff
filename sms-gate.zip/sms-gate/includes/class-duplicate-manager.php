<?php
/**
 * Duplicate Prevention Manager class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Duplicate_Manager
 * 
 * Handles duplicate prevention for SMS sending.
 * This class is responsible for tracking which order statuses have already been sent.
 * It does NOT send SMS, process templates, or call APIs.
 * 
 * @since 0.1.0
 */
class SMSGate_Duplicate_Manager {

	/**
	 * Meta key for storing sent statuses.
	 *
	 * @var string
	 */
	const SENT_STATUSES_META_KEY = '_smsgate_sent_statuses';

	/**
	 * Check if an order event has already been sent.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $event    Event name.
	 * @return bool True if already sent.
	 */
	public function has_been_sent( $order_id, $event ) {
		$sent_statuses = $this->get_sent_statuses( $order_id );
		return in_array( $event, $sent_statuses, true );
	}

	/**
	 * Mark an order event as sent.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $event    Event name.
	 */
	public function mark_as_sent( $order_id, $event ) {
		$sent_statuses = $this->get_sent_statuses( $order_id );
		
		if ( ! in_array( $event, $sent_statuses, true ) ) {
			$sent_statuses[] = $event;
			update_post_meta( $order_id, self::SENT_STATUSES_META_KEY, $sent_statuses );
		}
	}

	/**
	 * Get sent statuses for an order.
	 *
	 * @param int $order_id Order ID.
	 * @return array List of sent statuses.
	 */
	public function get_sent_statuses( $order_id ) {
		$sent_statuses = get_post_meta( $order_id, self::SENT_STATUSES_META_KEY, true );
		
		if ( ! is_array( $sent_statuses ) ) {
			return array();
		}
		
		return $sent_statuses;
	}

	/**
	 * Clear sent statuses for an order.
	 *
	 * @param int $order_id Order ID.
	 */
	public function clear_sent_statuses( $order_id ) {
		delete_post_meta( $order_id, self::SENT_STATUSES_META_KEY );
	}
}