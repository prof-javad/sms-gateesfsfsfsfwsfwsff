<?php
/**
 * Logger class for debugging and database logging.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Logger
 * 
 * Handles logging of SMS sending attempts to both file and database.
 * This class is responsible ONLY for logging and reading logs.
 * 
 * @since 0.2.0
 */
class SMSGate_Logger {

	/**
	 * Log level: Error.
	 *
	 * @var string
	 */
	const LEVEL_ERROR = 'error';

	/**
	 * Log level: Warning.
	 *
	 * @var string
	 */
	const LEVEL_WARNING = 'warning';

	/**
	 * Log level: Info.
	 *
	 * @var string
	 */
	const LEVEL_INFO = 'info';

	/**
	 * Log level: Debug.
	 *
	 * @var string
	 */
	const LEVEL_DEBUG = 'debug';

	/**
	 * Log file path.
	 *
	 * @var string
	 */
	private $log_file;

	/**
	 * Table name for database logs.
	 *
	 * @var string
	 */
	private $table_name;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$upload_dir   = wp_upload_dir();
		$this->log_file = $upload_dir['basedir'] . '/smsgate-logs.txt';
		
		global $wpdb;
		$this->table_name = $wpdb->prefix . 'smsgate_logs';
	}

	/**
	 * Log an SMS sending attempt.
	 *
	 * @param int    $order_id     Order ID.
	 * @param string $phone        Phone number.
	 * @param string $status       Order status.
	 * @param string $message      SMS message text.
	 * @param bool   $success      Whether sending was successful.
	 * @param string $provider     Provider name.
	 * @param mixed  $api_response API response (array or string).
	 * @param string $error        Error message (if any).
	 * @param string $error_code   Error code (if any).
	 * @return int|false The inserted log ID or false on failure.
	 */
	public function log_sms_attempt( $order_id, $phone, $status, $message, $success, $provider = '', $api_response = null, $error = '', $error_code = '' ) {
		// Sanitize and validate inputs.
		$order_id = absint( $order_id );
		$phone    = sanitize_text_field( $phone );
		$status   = sanitize_text_field( $status );
		$message  = wp_kses_post( $message );
		$success  = (bool) $success;
		$provider = sanitize_text_field( $provider );
		
		// Format API response.
		$api_response_serialized = $this->serialize_api_response( $api_response );
		
		$error      = sanitize_text_field( $error );
		$error_code = sanitize_text_field( $error_code );

		// Insert into database.
		$log_id = $this->insert_log( $order_id, $phone, $status, $message, $success, $provider, $api_response_serialized, $error, $error_code );

		// Also log to file for debugging.
		$this->log_to_file( $order_id, $phone, $status, $success, $error, $provider );

		return $log_id;
	}

	/**
	 * Insert a log entry into the database.
	 *
	 * @param int    $order_id     Order ID.
	 * @param string $phone        Phone number.
	 * @param string $status       Order status.
	 * @param string $message      SMS message text.
	 * @param bool   $success      Whether sending was successful.
	 * @param string $provider     Provider name.
	 * @param string $api_response Serialized API response.
	 * @param string $error        Error message.
	 * @param string $error_code   Error code.
	 * @return int|false Inserted ID or false.
	 */
	private function insert_log( $order_id, $phone, $status, $message, $success, $provider, $api_response, $error, $error_code ) {
		global $wpdb;

		$data = array(
			'order_id'     => $order_id,
			'phone'        => $phone,
			'status'       => $status,
			'message'      => $message,
			'success'      => $success ? 1 : 0,
			'provider'     => $provider,
			'api_response' => $api_response,
			'error_message' => $error,
			'error_code'   => $error_code,
			'created_at'   => current_time( 'mysql' ),
		);

		$format = array(
			'%d',
			'%s',
			'%s',
			'%s',
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
		);

		$result = $wpdb->insert( $this->table_name, $data, $format );

		if ( false === $result ) {
			return false;
		}

		return $wpdb->insert_id;
	}

	/**
	 * Serialize API response for storage.
	 *
	 * @param mixed $response API response.
	 * @return string Serialized response.
	 */
	private function serialize_api_response( $response ) {
		if ( is_null( $response ) ) {
			return '';
		}

		if ( is_string( $response ) ) {
			return $response;
		}

		return wp_json_encode( $response );
	}

	/**
	 * Log to file for debugging.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $phone    Phone number.
	 * @param string $status   Order status.
	 * @param bool   $success  Whether sending was successful.
	 * @param string $error    Error message.
	 * @param string $provider Provider name.
	 */
	private function log_to_file( $order_id, $phone, $status, $success, $error, $provider ) {
		$timestamp = current_time( 'Y-m-d H:i:s' );
		$result    = $success ? 'SUCCESS' : 'FAILED';
		$error_msg = $error ? " - Error: {$error}" : '';
		$entry     = "[{$timestamp}] [{$result}] Order: {$order_id} | Phone: {$phone} | Status: {$status} | Provider: {$provider}{$error_msg}\n";

		error_log( $entry, 3, $this->log_file );
	}

	/**
	 * Create the database table for logs.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function create_table() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_name      = $this->table_name;

		$sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			order_id bigint(20) NOT NULL DEFAULT 0,
			phone varchar(50) NOT NULL DEFAULT '',
			status varchar(50) NOT NULL DEFAULT '',
			message text NOT NULL,
			success tinyint(1) NOT NULL DEFAULT 0,
			provider varchar(100) NOT NULL DEFAULT '',
			api_response longtext,
			error_message varchar(255) NOT NULL DEFAULT '',
			error_code varchar(50) NOT NULL DEFAULT '',
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY order_id (order_id),
			KEY phone (phone),
			KEY success (success),
			KEY created_at (created_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		return true;
	}

	/**
	 * Drop the database table.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function drop_table() {
		global $wpdb;

		// @codingStandardsIgnoreStart
		return $wpdb->query( "DROP TABLE IF EXISTS {$this->table_name}" );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Get logs for a specific order.
	 *
	 * @param int   $order_id Order ID.
	 * @param int   $limit    Maximum number of logs to retrieve.
	 * @param int   $offset   Offset for pagination.
	 * @return array Array of log entries.
	 */
	public function get_logs_by_order( $order_id, $limit = 10, $offset = 0 ) {
		global $wpdb;

		$order_id = absint( $order_id );
		$limit    = absint( $limit );
		$offset   = absint( $offset );

		$sql = $wpdb->prepare(
			"SELECT * FROM {$this->table_name} WHERE order_id = %d ORDER BY created_at DESC LIMIT %d OFFSET %d",
			$order_id,
			$limit,
			$offset
		);

		// @codingStandardsIgnoreStart
		return $wpdb->get_results( $sql, ARRAY_A );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Get logs with filters.
	 *
	 * @param array $filters Array of filters (order_id, phone, success, status, from_date, to_date).
	 * @param int   $limit   Maximum number of logs to retrieve.
	 * @param int   $offset  Offset for pagination.
	 * @return array Array of log entries.
	 */
	public function get_logs( $filters = array(), $limit = 20, $offset = 0 ) {
		global $wpdb;

		$limit  = absint( $limit );
		$offset = absint( $offset );

		$where_conditions = array();
		$where_values     = array();

		if ( ! empty( $filters['order_id'] ) ) {
			$where_conditions[] = 'order_id = %d';
			$where_values[]     = absint( $filters['order_id'] );
		}

		if ( ! empty( $filters['phone'] ) ) {
			$where_conditions[] = 'phone = %s';
			$where_values[]     = sanitize_text_field( $filters['phone'] );
		}

		if ( isset( $filters['success'] ) && is_bool( $filters['success'] ) ) {
			$where_conditions[] = 'success = %d';
			$where_values[]     = $filters['success'] ? 1 : 0;
		}

		if ( ! empty( $filters['status'] ) ) {
			$where_conditions[] = 'status = %s';
			$where_values[]     = sanitize_text_field( $filters['status'] );
		}

		if ( ! empty( $filters['from_date'] ) ) {
			$where_conditions[] = 'created_at >= %s';
			$where_values[]     = sanitize_text_field( $filters['from_date'] );
		}

		if ( ! empty( $filters['to_date'] ) ) {
			$where_conditions[] = 'created_at <= %s';
			$where_values[]     = sanitize_text_field( $filters['to_date'] );
		}

		$where_clause = '';
		if ( ! empty( $where_conditions ) ) {
			$where_clause = 'WHERE ' . implode( ' AND ', $where_conditions );
		}

		$sql = "SELECT * FROM {$this->table_name} {$where_clause} ORDER BY created_at DESC LIMIT %d OFFSET %d";

		if ( ! empty( $where_values ) ) {
			$where_values[] = $limit;
			$where_values[] = $offset;
			// @codingStandardsIgnoreStart
			return $wpdb->get_results( $wpdb->prepare( $sql, $where_values ), ARRAY_A );
			// @codingStandardsIgnoreEnd
		}

		// @codingStandardsIgnoreStart
		return $wpdb->get_results( $wpdb->prepare( $sql, $limit, $offset ), ARRAY_A );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Count logs with filters.
	 *
	 * @param array $filters Array of filters.
	 * @return int Number of logs.
	 */
	public function count_logs( $filters = array() ) {
		global $wpdb;

		$where_conditions = array();
		$where_values     = array();

		if ( ! empty( $filters['order_id'] ) ) {
			$where_conditions[] = 'order_id = %d';
			$where_values[]     = absint( $filters['order_id'] );
		}

		if ( ! empty( $filters['phone'] ) ) {
			$where_conditions[] = 'phone = %s';
			$where_values[]     = sanitize_text_field( $filters['phone'] );
		}

		if ( isset( $filters['success'] ) && is_bool( $filters['success'] ) ) {
			$where_conditions[] = 'success = %d';
			$where_values[]     = $filters['success'] ? 1 : 0;
		}

		if ( ! empty( $filters['status'] ) ) {
			$where_conditions[] = 'status = %s';
			$where_values[]     = sanitize_text_field( $filters['status'] );
		}

		if ( ! empty( $filters['from_date'] ) ) {
			$where_conditions[] = 'created_at >= %s';
			$where_values[]     = sanitize_text_field( $filters['from_date'] );
		}

		if ( ! empty( $filters['to_date'] ) ) {
			$where_conditions[] = 'created_at <= %s';
			$where_values[]     = sanitize_text_field( $filters['to_date'] );
		}

		$where_clause = '';
		if ( ! empty( $where_conditions ) ) {
			$where_clause = 'WHERE ' . implode( ' AND ', $where_conditions );
		}

		$sql = "SELECT COUNT(*) FROM {$this->table_name} {$where_clause}";

		if ( ! empty( $where_values ) ) {
			// @codingStandardsIgnoreStart
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, $where_values ) );
			// @codingStandardsIgnoreEnd
		}

		// @codingStandardsIgnoreStart
		return (int) $wpdb->get_var( $sql );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Delete logs older than a certain date.
	 *
	 * @param string $date Date in Y-m-d H:i:s format.
	 * @return int|false Number of deleted rows or false on error.
	 */
	public function delete_old_logs( $date ) {
		global $wpdb;

		$date = sanitize_text_field( $date );

		$sql = $wpdb->prepare(
			"DELETE FROM {$this->table_name} WHERE created_at < %s",
			$date
		);

		// @codingStandardsIgnoreStart
		return $wpdb->query( $sql );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Log error message.
	 *
	 * @param string $message Message.
	 * @param array  $context Context data.
	 */
	public function error( $message, $context = array() ) {
		$this->log( self::LEVEL_ERROR, $message, $context );
	}

	/**
	 * Log warning message.
	 *
	 * @param string $message Message.
	 * @param array  $context Context data.
	 */
	public function warning( $message, $context = array() ) {
		$this->log( self::LEVEL_WARNING, $message, $context );
	}

	/**
	 * Log info message.
	 *
	 * @param string $message Message.
	 * @param array  $context Context data.
	 */
	public function info( $message, $context = array() ) {
		$this->log( self::LEVEL_INFO, $message, $context );
	}

	/**
	 * Log debug message.
	 *
	 * @param string $message Message.
	 * @param array  $context Context data.
	 */
	public function debug( $message, $context = array() ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			$this->log( self::LEVEL_DEBUG, $message, $context );
		}
	}

	/**
	 * Write log entry to file.
	 *
	 * @param string $level Log level.
	 * @param string $message Message.
	 * @param array  $context Context data.
	 */
	private function log( $level, $message, $context = array() ) {
		$timestamp = current_time( 'Y-m-d H:i:s' );
		$context   = ! empty( $context ) ? ' ' . wp_json_encode( $context ) : '';
		$entry     = "[{$timestamp}] [{$level}] {$message}{$context}\n";

		error_log( $entry, 3, $this->log_file );
	}
}