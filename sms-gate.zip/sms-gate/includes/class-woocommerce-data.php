<?php
/**
 * WooCommerce Data Layer class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_WooCommerce_Data
 * 
 * Handles WooCommerce order data extraction.
 * This class is responsible for extracting order information in a standardized format.
 * It does NOT send SMS, process templates, or call APIs.
 * 
 * @since 0.1.0
 */
class SMSGate_WooCommerce_Data {

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	public function is_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Get order data in standardized format.
	 *
	 * @param int|WC_Order $order Order ID or WC_Order object.
	 * @return array Standardized order data.
	 */
	public function get_order_data( $order ) {
		// Check if WooCommerce is active.
		if ( ! $this->is_active() ) {
			return $this->error_response( __( 'WooCommerce is not active', 'sms-gate' ) );
		}

		// Get WC_Order object.
		$order = $this->get_order_object( $order );

		if ( ! $order ) {
			return $this->error_response( __( 'Order not found', 'sms-gate' ) );
		}

		// Extract order data.
		return array(
			'success' => true,
			'data'    => array(
				'order'           => $this->get_order_info( $order ),
				'customer'        => $this->get_customer_info( $order ),
				'billing'         => $this->get_billing_info( $order ),
				'shipping'        => $this->get_shipping_info( $order ),
				'payment'         => $this->get_payment_info( $order ),
				'shipping_method' => $this->get_shipping_method_info( $order ),
				'items'           => $this->get_items_info( $order ),
				'meta'            => $this->get_order_meta( $order ),
			),
		);
	}

	/**
	 * Get WC_Order object.
	 *
	 * @param int|WC_Order $order Order ID or WC_Order object.
	 * @return WC_Order|false
	 */
	private function get_order_object( $order ) {
		if ( $order instanceof WC_Order ) {
			return $order;
		}

		if ( is_numeric( $order ) ) {
			$order_object = wc_get_order( absint( $order ) );
			if ( $order_object instanceof WC_Order ) {
				return $order_object;
			}
		}

		return false;
	}

	/**
	 * Get basic order information.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_order_info( $order ) {
		return array(
			'id'                      => $order->get_id(),
			'number'                  => $order->get_order_number(),
			'status'                  => $order->get_status(),
			'status_label'            => wc_get_order_status_name( $order->get_status() ),
			'date_created'            => $this->format_date( $order->get_date_created() ),
			'date_modified'           => $this->format_date( $order->get_date_modified() ),
			'currency'                => $order->get_currency(),
			'total'                   => (float) $order->get_total(),
			'total_formatted'         => wc_price( $order->get_total() ),
			'discount'                => (float) $order->get_discount_total(),
			'discount_formatted'      => wc_price( $order->get_discount_total() ),
			'shipping_total'          => (float) $order->get_shipping_total(),
			'shipping_total_formatted' => wc_price( $order->get_shipping_total() ),
			'tax_total'               => (float) $order->get_total_tax(),
			'tax_total_formatted'     => wc_price( $order->get_total_tax() ),
		);
	}

	/**
	 * Get customer information.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_customer_info( $order ) {
		$user = $order->get_user();

		return array(
			'id'         => $order->get_customer_id(),
			'username'   => $user ? $user->user_login : '',
			'first_name' => $order->get_billing_first_name(),
			'last_name'  => $order->get_billing_last_name(),
			'full_name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'email'      => $order->get_billing_email(),
			'phone'      => $order->get_billing_phone(),
		);
	}

	/**
	 * Get billing information.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_billing_info( $order ) {
		return array(
			'first_name'    => $order->get_billing_first_name(),
			'last_name'     => $order->get_billing_last_name(),
			'company'       => $order->get_billing_company(),
			'address_1'     => $order->get_billing_address_1(),
			'address_2'     => $order->get_billing_address_2(),
			'city'          => $order->get_billing_city(),
			'state'         => $order->get_billing_state(),
			'postcode'      => $order->get_billing_postcode(),
			'country'       => $order->get_billing_country(),
			'country_name'  => $this->get_country_name( $order->get_billing_country() ),
			'email'         => $order->get_billing_email(),
			'phone'         => $order->get_billing_phone(),
			'full_address'  => $this->format_address( $order, 'billing' ),
		);
	}

	/**
	 * Get shipping information.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_shipping_info( $order ) {
		return array(
			'first_name'    => $order->get_shipping_first_name(),
			'last_name'     => $order->get_shipping_last_name(),
			'company'       => $order->get_shipping_company(),
			'address_1'     => $order->get_shipping_address_1(),
			'address_2'     => $order->get_shipping_address_2(),
			'city'          => $order->get_shipping_city(),
			'state'         => $order->get_shipping_state(),
			'postcode'      => $order->get_shipping_postcode(),
			'country'       => $order->get_shipping_country(),
			'country_name'  => $this->get_country_name( $order->get_shipping_country() ),
			'full_address'  => $this->format_address( $order, 'shipping' ),
		);
	}

	/**
	 * Get payment information.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_payment_info( $order ) {
		return array(
			'method_id'      => $order->get_payment_method(),
			'method_title'   => $order->get_payment_method_title(),
			'transaction_id' => $order->get_transaction_id(),
		);
	}

	/**
	 * Get shipping method information.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_shipping_method_info( $order ) {
		$methods = $order->get_shipping_methods();
		$shipping_methods = array();

		foreach ( $methods as $method ) {
			$shipping_methods[] = array(
				'id'               => $method->get_method_id(),
				'title'            => $method->get_name(),
				'total'            => (float) $method->get_total(),
				'total_formatted'  => wc_price( $method->get_total() ),
			);
		}

		return $shipping_methods;
	}

	/**
	 * Get order items information.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_items_info( $order ) {
		$items = array();

		foreach ( $order->get_items() as $item_id => $item ) {
			$product = $item->get_product();

			$items[] = array(
				'id'              => $item_id,
				'product_id'      => $item->get_product_id(),
				'variation_id'    => $item->get_variation_id(),
				'name'            => $item->get_name(),
				'sku'             => $product ? $product->get_sku() : '',
				'quantity'        => (int) $item->get_quantity(),
				'price'           => (float) $item->get_subtotal(),
				'price_formatted' => wc_price( $item->get_subtotal() ),
				'total'           => (float) $item->get_total(),
				'total_formatted' => wc_price( $item->get_total() ),
				'meta'            => $this->get_item_meta( $item ),
			);
		}

		return $items;
	}

	/**
	 * Get order meta data.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_order_meta( $order ) {
		$meta = array();

		// Get important meta keys.
		$meta_keys = array(
			'_order_key',
			'_customer_user_agent',
			'_customer_ip_address',
		);

		foreach ( $meta_keys as $key ) {
			$value = $order->get_meta( $key );
			if ( ! empty( $value ) ) {
				$meta[ $key ] = $value;
			}
		}

		return $meta;
	}

	/**
	 * Get item meta data.
	 *
	 * @param WC_Order_Item $item Order item.
	 * @return array
	 */
	private function get_item_meta( $item ) {
		$meta = array();

		// Get all meta data for the item.
		$meta_data = $item->get_meta_data();

		foreach ( $meta_data as $meta_item ) {
			$key = $meta_item->key;
			$value = $meta_item->value;

			// Skip internal meta keys.
			if ( '_' === substr( $key, 0, 1 ) ) {
				continue;
			}

			$meta[ $key ] = $value;
		}

		return $meta;
	}

	/**
	 * Get country name from country code.
	 *
	 * @param string $country_code Country code.
	 * @return string
	 */
	private function get_country_name( $country_code ) {
		if ( empty( $country_code ) ) {
			return '';
		}

		$countries = WC()->countries->get_countries();
		return isset( $countries[ $country_code ] ) ? $countries[ $country_code ] : $country_code;
	}

	/**
	 * Format date for output.
	 *
	 * @param WC_DateTime|null $date Date object.
	 * @return string
	 */
	private function format_date( $date ) {
		if ( ! $date instanceof WC_DateTime ) {
			return '';
		}

		return $date->format( 'Y-m-d H:i:s' );
	}

	/**
	 * Format address for output.
	 *
	 * @param WC_Order $order Order object.
	 * @param string   $type Address type (billing or shipping).
	 * @return string
	 */
	private function format_address( $order, $type ) {
		if ( 'billing' === $type ) {
			$address = array(
				$order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
				$order->get_billing_company(),
				$order->get_billing_address_1(),
				$order->get_billing_address_2(),
				$order->get_billing_city(),
				$order->get_billing_state(),
				$order->get_billing_postcode(),
				$this->get_country_name( $order->get_billing_country() ),
			);
		} else {
			$address = array(
				$order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
				$order->get_shipping_company(),
				$order->get_shipping_address_1(),
				$order->get_shipping_address_2(),
				$order->get_shipping_city(),
				$order->get_shipping_state(),
				$order->get_shipping_postcode(),
				$this->get_country_name( $order->get_shipping_country() ),
			);
		}

		// Remove empty values.
		$address = array_filter( $address );

		return implode( ', ', $address );
	}

	/**
	 * Create error response.
	 *
	 * @param string $message Error message.
	 * @return array
	 */
	private function error_response( $message ) {
		return array(
			'success' => false,
			'error'   => $message,
			'data'    => null,
		);
	}
}