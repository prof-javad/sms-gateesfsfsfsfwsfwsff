<?php
/**
 * Autoloader and bootstrap class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Loader
 */
class SMSGate_Loader {

	/**
	 * Plugin instance.
	 *
	 * @var SMSGate_Plugin
	 */
	private $plugin;

	/**
	 * Register autoloader and hooks.
	 */
	public function register() {
		spl_autoload_register( array( $this, 'autoload' ) );
		
		$this->plugin = new SMSGate_Plugin();
		$this->plugin->init();
		
		add_action( 'init', array( $this, 'load_textdomain' ) );
	}

	/**
	 * Autoloader for plugin classes.
	 *
	 * @param string $class Class name.
	 */
	public function autoload( $class ) {
		$prefix = 'SMSGate_';
		$len    = strlen( $prefix );

		if ( 0 !== strncmp( $prefix, $class, $len ) ) {
			return;
		}

		$relative_class = substr( $class, $len );
		$class_name     = strtolower( str_replace( '_', '-', $relative_class ) );
		
		// Try includes directory first.
		$file = SMSGATE_PATH . 'includes/class-' . $class_name . '.php';
		if ( file_exists( $file ) ) {
			require_once $file;
			return;
		}
		
		// Try admin directory.
		$file = SMSGATE_PATH . 'admin/class-' . $class_name . '.php';
		if ( file_exists( $file ) ) {
			require_once $file;
			return;
		}
		
		// Try public directory.
		$file = SMSGATE_PATH . 'public/class-' . $class_name . '.php';
		if ( file_exists( $file ) ) {
			require_once $file;
			return;
		}
	}

	/**
	 * Load plugin textdomain.
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'sms-gate',
			false,
			dirname( SMSGATE_BASENAME ) . '/languages'
		);
	}

	/**
	 * Activation hook.
	 */
	public static function activate() {
		$plugin = new SMSGate_Plugin();
		$plugin->activate();
	}

	/**
	 * Deactivation hook.
	 */
	public static function deactivate() {
		$plugin = new SMSGate_Plugin();
		$plugin->deactivate();
	}
}