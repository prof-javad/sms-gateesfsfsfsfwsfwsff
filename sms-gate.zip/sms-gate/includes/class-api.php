<?php
/**
 * HTTP Client class for API communication.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_API
 * 
 * A generic HTTP client for making API requests.
 * This class has no knowledge of SMS, providers, or business logic.
 */
class SMSGate_API {

	/**
	 * Default timeout in seconds.
	 *
	 * @var int
	 */
	private $timeout = 30;

	/**
	 * Default headers.
	 *
	 * @var array
	 */
	private $headers = array();

	/**
	 * Logger instance.
	 *
	 * @var SMSGate_Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @param SMSGate_Logger $logger Logger instance.
	 */
	public function __construct( $logger = null ) {
		$this->logger = $logger ? $logger : new SMSGate_Logger();
	}

	/**
	 * Set request timeout.
	 *
	 * @param int $timeout Timeout in seconds.
	 */
	public function set_timeout( $timeout ) {
		$this->timeout = absint( $timeout );
	}

	/**
	 * Set default headers.
	 *
	 * @param array $headers Headers array.
	 */
	public function set_headers( $headers ) {
		$this->headers = wp_parse_args( $headers, $this->headers );
	}

	/**
	 * Add a header.
	 *
	 * @param string $key   Header key.
	 * @param string $value Header value.
	 */
	public function add_header( $key, $value ) {
		$this->headers[ $key ] = $value;
	}

	/**
	 * Send a GET request.
	 *
	 * @param string $url     Request URL.
	 * @param array  $headers Additional headers.
	 * @return array Response data.
	 */
	public function get( $url, $headers = array() ) {
		return $this->request( 'GET', $url, null, $headers );
	}

	/**
	 * Send a POST request.
	 *
	 * @param string $url     Request URL.
	 * @param mixed  $body    Request body (will be JSON encoded).
	 * @param array  $headers Additional headers.
	 * @return array Response data.
	 */
	public function post( $url, $body = null, $headers = array() ) {
		return $this->request( 'POST', $url, $body, $headers );
	}

	/**
	 * Send a PUT request.
	 *
	 * @param string $url     Request URL.
	 * @param mixed  $body    Request body (will be JSON encoded).
	 * @param array  $headers Additional headers.
	 * @return array Response data.
	 */
	public function put( $url, $body = null, $headers = array() ) {
		return $this->request( 'PUT', $url, $body, $headers );
	}

	/**
	 * Send a DELETE request.
	 *
	 * @param string $url     Request URL.
	 * @param array  $headers Additional headers.
	 * @return array Response data.
	 */
	public function delete( $url, $headers = array() ) {
		return $this->request( 'DELETE', $url, null, $headers );
	}

	/**
	 * Send an HTTP request.
	 *
	 * @param string $method  HTTP method.
	 * @param string $url     Request URL.
	 * @param mixed  $body    Request body (will be JSON encoded).
	 * @param array  $headers Additional headers.
	 * @return array Standardized response.
	 */
	private function request( $method, $url, $body = null, $headers = array() ) {
		try {
			$url = esc_url_raw( $url );

			if ( empty( $url ) ) {
				throw new Exception( __( 'Invalid URL', 'sms-gate' ) );
			}

			$args = $this->build_request_args( $method, $url, $body, $headers );
			$response = $this->send_request( $url, $args );
			$validated = $this->validate_response( $response );
			
			return $this->format_response( $validated );
		} catch ( Exception $e ) {
			$this->logger->error( 'API request failed', array( 'error' => $e->getMessage() ) );
			return $this->error_response( $e->getMessage() );
		}
	}

	/**
	 * Build request arguments.
	 *
	 * @param string $method  HTTP method.
	 * @param string $url     Request URL.
	 * @param mixed  $body    Request body.
	 * @param array  $headers Additional headers.
	 * @return array
	 */
	private function build_request_args( $method, $url, $body, $headers ) {
		$args = array(
			'method'  => $method,
			'timeout' => $this->timeout,
			'headers' => wp_parse_args( $headers, $this->headers ),
		);

		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
			$args['data_format'] = 'body';
		}

		return $args;
	}

	/**
	 * Send the HTTP request.
	 *
	 * @param string $url  Request URL.
	 * @param array  $args Request arguments.
	 * @return array|\WP_Error
	 */
	private function send_request( $url, $args ) {
		$this->logger->debug( 'Sending HTTP request', array( 
			'url'    => $url, 
			'method' => $args['method'] 
		) );

		switch ( $args['method'] ) {
			case 'GET':
				return wp_remote_get( $url, $args );
			case 'POST':
				return wp_remote_post( $url, $args );
			case 'PUT':
			case 'DELETE':
			default:
				return wp_remote_request( $url, $args );
		}
	}

	/**
	 * Validate the response.
	 *
	 * @param array|\WP_Error $response HTTP response.
	 * @return array Validated response.
	 * @throws Exception On validation failure.
	 */
	private function validate_response( $response ) {
		if ( is_wp_error( $response ) ) {
			throw new Exception( $response->get_error_message() );
		}

		if ( empty( $response ) ) {
			throw new Exception( __( 'Empty response', 'sms-gate' ) );
		}

		return $response;
	}

	/**
	 * Format the response.
	 *
	 * @param array $response HTTP response.
	 * @return array Standardized response.
	 */
	private function format_response( $response ) {
		$status_code = wp_remote_retrieve_response_code( $response );
		$headers     = wp_remote_retrieve_headers( $response );
		$body        = wp_remote_retrieve_body( $response );
		$decoded     = json_decode( $body, true );

		return array(
			'success'      => $status_code < 400,
			'status_code'  => $status_code,
			'headers'      => $headers,
			'body'         => $body,
			'decoded_body' => $decoded,
			'raw_response' => $response,
		);
	}

	/**
	 * Create error response.
	 *
	 * @param string $message Error message.
	 * @return array
	 */
	private function error_response( $message ) {
		return array(
			'success'      => false,
			'status_code'  => 0,
			'headers'      => array(),
			'body'         => '',
			'decoded_body' => null,
			'raw_response' => null,
			'error'        => $message,
		);
	}
}