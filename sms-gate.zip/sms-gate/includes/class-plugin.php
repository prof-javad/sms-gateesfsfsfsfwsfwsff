<?php
/**
 * Main plugin class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Plugin
 * 
 * Orchestrates the SMS sending pipeline.
 * Listens to internal events and coordinates the flow:
 * Event → Order Data → Phone Validation → Template → SMS Service → API
 */
class SMSGate_Plugin {

	/**
	 * Settings instance.
	 *
	 * @var SMSGate_Settings
	 */
	private $settings;

	/**
	 * API instance.
	 *
	 * @var SMSGate_API
	 */
	private $api;

	/**
	 * SMS Service instance.
	 *
	 * @var SMSGate_SMS_Service
	 */
	private $sms_service;

	/**
	 * Admin instance.
	 *
	 * @var SMSGate_Admin
	 */
	private $admin;

	/**
	 * Public instance.
	 *
	 * @var SMSGate_Public
	 */
	private $public;

	/**
	 * WooCommerce instance.
	 *
	 * @var SMSGate_WooCommerce
	 */
	private $woocommerce;

	/**
	 * Data layer instance.
	 *
	 * @var SMSGate_WooCommerce_Data
	 */
	private $data_layer;

	/**
	 * Duplicate Manager instance.
	 *
	 * @var SMSGate_Duplicate_Manager
	 */
	private $duplicate_manager;

	/**
	 * Logger instance.
	 *
	 * @var SMSGate_Logger
	 */
	private $logger;

	/**
	 * Initialize the plugin.
	 */
	public function init() {
		$this->load_dependencies();
		$this->init_hooks();
	}

	/**
	 * Load plugin dependencies.
	 */
	private function load_dependencies() {
		$this->settings          = new SMSGate_Settings();
		$this->logger            = new SMSGate_Logger();
		$this->api               = new SMSGate_API( $this->logger );
		$this->sms_service       = new SMSGate_SMS_Service( $this->api, $this->settings );
		$this->data_layer        = new SMSGate_WooCommerce_Data();
		$this->duplicate_manager = new SMSGate_Duplicate_Manager();
		
		if ( is_admin() ) {
			$this->admin = new SMSGate_Admin( $this->settings, $this->sms_service );
		} else {
			$this->public = new SMSGate_Public();
		}

		// Initialize WooCommerce integration if active.
		$this->woocommerce = new SMSGate_WooCommerce();
	}

	/**
	 * Initialize WordPress hooks.
	 */
	private function init_hooks() {
		// WooCommerce integration (only if active).
		if ( $this->woocommerce->is_active() ) {
			$this->woocommerce->register_hooks();
		}

		// Listen to internal order events.
		add_action( 'smsgate_order_event', array( $this, 'handle_order_event' ), 10, 1 );
	}

	/**
	 * Handle order event and process SMS pipeline.
	 *
	 * @param array $payload Event payload from WooCommerce.
	 */
	public function handle_order_event( $payload ) {
		// Validate payload.
		if ( empty( $payload['event'] ) || empty( $payload['order_id'] ) ) {
			return;
		}

		$event    = $payload['event'];
		$order_id = $payload['order_id'];

		// Check if this status is enabled.
		if ( ! $this->is_status_enabled( $event ) ) {
			return;
		}

		// Check if already sent for this status.
		if ( $this->duplicate_manager->has_been_sent( $order_id, $event ) ) {
			return;
		}

		// Get order data.
		$order_data = $this->get_order_data( $order_id );

		if ( empty( $order_data ) ) {
			return;
		}

		// Get customer phone.
		$phone = $this->get_customer_phone( $order_data );

		if ( empty( $phone ) ) {
			return;
		}

		// Normalize and validate phone.
		$normalized_phone = SMSGate_Phone::normalize( $phone );

		if ( ! $normalized_phone ) {
			return;
		}

		// Get template for this event.
		$template = $this->get_template_for_event( $event );

		if ( empty( $template ) ) {
			return;
		}

		// Render the template with order data.
		$message = SMSGate_Template::render( $template, $order_data );

		if ( empty( $message ) ) {
			return;
		}

		// Send SMS.
		$result = $this->sms_service->send( $normalized_phone, $message );

		// Log the attempt.
		$order_status = isset( $order_data['order']['status'] ) ? $order_data['order']['status'] : $event;
		
		$this->logger->log_sms_attempt(
			$order_id,
			$normalized_phone,
			$order_status,
			$message,
			$result['success'],
			$result['provider'],
			$result['response'],
			$result['error'],
			$result['error_code']
		);

		// Only mark as sent if successful.
		if ( $result['success'] ) {
			$this->duplicate_manager->mark_as_sent( $order_id, $event );
		}
	}

	/**
	 * Check if a status is enabled in settings.
	 *
	 * @param string $status Status key.
	 * @return bool
	 */
	private function is_status_enabled( $status ) {
		$status_map = array(
			'new_order'   => 'enable_new_order',
			'processing'  => 'enable_processing',
			'completed'   => 'enable_completed',
			'cancelled'   => 'enable_cancelled',
		);

		if ( ! isset( $status_map[ $status ] ) ) {
			return false;
		}

		return 'yes' === $this->settings->get( $status_map[ $status ], 'yes' );
	}

	/**
	 * Get order data by order ID.
	 *
	 * @param int $order_id Order ID.
	 * @return array|false
	 */
	private function get_order_data( $order_id ) {
		$result = $this->data_layer->get_order_data( $order_id );

		if ( ! $result['success'] ) {
			return false;
		}

		return $result['data'];
	}

	/**
	 * Get customer phone from order data.
	 *
	 * @param array $order_data Order data.
	 * @return string|false
	 */
	private function get_customer_phone( $order_data ) {
		if ( isset( $order_data['customer']['phone'] ) && ! empty( $order_data['customer']['phone'] ) ) {
			return $order_data['customer']['phone'];
		}

		if ( isset( $order_data['billing']['phone'] ) && ! empty( $order_data['billing']['phone'] ) ) {
			return $order_data['billing']['phone'];
		}

		return false;
	}

	/**
	 * Get template for a specific event.
	 *
	 * @param string $event Event name.
	 * @return string|false
	 */
	private function get_template_for_event( $event ) {
		$template_map = array(
			'new_order'   => 'template_new_order',
			'processing'  => 'template_processing',
			'completed'   => 'template_completed',
			'cancelled'   => 'template_cancelled',
		);

		if ( ! isset( $template_map[ $event ] ) ) {
			return false;
		}

		$template = $this->settings->get( $template_map[ $event ], '' );

		if ( empty( $template ) ) {
			return false;
		}

		return $template;
	}

	/**
	 * Activation hook.
	 */
	public function activate() {
		// Create the logs table.
		$this->logger->create_table();
	}

	/**
	 * Deactivation hook.
	 */
	public function deactivate() {
		// Deactivation logic placeholder - we keep logs by default.
	}
}