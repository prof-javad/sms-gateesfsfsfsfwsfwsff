<?php
/**
 * Template rendering class.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Template
 * 
 * Handles template parsing and placeholder replacement.
 * This class has no knowledge of SMS, APIs, or WooCommerce hooks.
 * It only processes templates with provided data arrays.
 */
class SMSGate_Template {

	/**
	 * Template text.
	 *
	 * @var string
	 */
	private $template = '';

	/**
	 * Data array for placeholder replacement.
	 *
	 * @var array
	 */
	private $data = array();

	/**
	 * Constructor.
	 *
	 * @param string $template Template text.
	 * @param array  $data     Data array for replacement.
	 */
	public function __construct( $template = '', $data = array() ) {
		$this->template = $template;
		$this->data     = $this->merge_with_system_variables( (array) $data );
	}

	/**
	 * Set template text.
	 *
	 * @param string $template Template text.
	 * @return self
	 */
	public function set_template( $template ) {
		$this->template = (string) $template;
		return $this;
	}

	/**
	 * Set data array.
	 *
	 * @param array $data Data array.
	 * @return self
	 */
	public function set_data( $data ) {
		$this->data = $this->merge_with_system_variables( (array) $data );
		return $this;
	}

	/**
	 * Process template and replace placeholders.
	 *
	 * @param string $template Optional template text.
	 * @param array  $data     Optional data array.
	 * @return string Processed template.
	 */
	public function process( $template = null, $data = null ) {
		if ( null !== $template ) {
			$this->set_template( $template );
		}

		if ( null !== $data ) {
			$this->set_data( $data );
		}

		if ( empty( $this->template ) ) {
			return '';
		}

		if ( empty( $this->data ) ) {
			return $this->template;
		}

		// Extract all placeholders from current template.
		$placeholders = $this->extract_placeholders( $this->template );

		if ( empty( $placeholders ) ) {
			return $this->template;
		}

		// Replace each placeholder.
		$result = $this->template;

		foreach ( $placeholders as $placeholder ) {
			$value = $this->resolve_placeholder( $placeholder, $this->data );
			$result = str_replace( '{' . $placeholder . '}', $value, $result );
		}

		return $result;
	}

	/**
	 * Extract all placeholders from template.
	 *
	 * @param string $template Template text.
	 * @return array List of unique placeholders.
	 */
	private function extract_placeholders( $template ) {
		preg_match_all( '/\{([a-zA-Z0-9._-]+)\}/', $template, $matches );
		return array_unique( $matches[1] );
	}

	/**
	 * Resolve a placeholder value from data array.
	 *
	 * @param string $placeholder Placeholder key (supports dot notation).
	 * @param array  $data        Data array.
	 * @return string Resolved value.
	 */
	private function resolve_placeholder( $placeholder, $data ) {
		// Handle dot notation for nested data.
		if ( strpos( $placeholder, '.' ) !== false ) {
			$keys = explode( '.', $placeholder );
			$value = $this->get_nested_value( $keys, $data );
		} else {
			// Simple key lookup.
			$value = isset( $data[ $placeholder ] ) ? $data[ $placeholder ] : null;
		}

		// Convert to string, handle null and arrays.
		if ( is_null( $value ) ) {
			return '';
		}

		if ( is_array( $value ) ) {
			// For arrays, try to get a readable representation.
			return $this->format_array_value( $value );
		}

		if ( is_bool( $value ) ) {
			return $value ? 'yes' : 'no';
		}

		return (string) $value;
	}

	/**
	 * Get nested value from array using keys.
	 *
	 * @param array $keys Array of keys.
	 * @param array $data Data array.
	 * @return mixed|null
	 */
	private function get_nested_value( $keys, $data ) {
		$current = $data;

		foreach ( $keys as $key ) {
			if ( is_array( $current ) && isset( $current[ $key ] ) ) {
				$current = $current[ $key ];
			} else {
				return null;
			}
		}

		return $current;
	}

	/**
	 * Format array value for output.
	 *
	 * @param array $value Array value.
	 * @return string
	 */
	private function format_array_value( $value ) {
		// Check if it's a list of items (like shipping methods).
		if ( isset( $value[0] ) && is_array( $value[0] ) ) {
			$items = array();
			foreach ( $value as $item ) {
				if ( isset( $item['title'] ) ) {
					$items[] = $item['title'];
				} elseif ( isset( $item['name'] ) ) {
					$items[] = $item['name'];
				} else {
					$items[] = implode( ', ', $item );
				}
			}
			return implode( ', ', $items );
		}

		// Simple array with scalar values.
		return implode( ', ', array_filter( $value, 'is_scalar' ) );
	}

	/**
	 * Get all available placeholders from data array.
	 *
	 * @param array  $data      Data array.
	 * @param string $prefix    Optional prefix for nested keys.
	 * @param int    $max_depth Maximum depth for recursion.
	 * @return array List of available placeholders.
	 */
	public function get_available_variables( $data = null, $prefix = '', $max_depth = 3 ) {
		if ( null === $data ) {
			$data = $this->data;
		}

		$variables = array();

		foreach ( $data as $key => $value ) {
			$full_key = $prefix ? $prefix . '.' . $key : $key;

			// Skip if we've reached max depth.
			if ( $max_depth <= 0 ) {
				$variables[] = $full_key;
				continue;
			}

			if ( is_array( $value ) && ! empty( $value ) && $this->is_nested_array( $value ) ) {
				// Recursively get nested variables.
				$nested = $this->get_available_variables( $value, $full_key, $max_depth - 1 );
				$variables = array_merge( $variables, $nested );
			} else {
				$variables[] = $full_key;
			}
		}

		return $variables;
	}

	/**
	 * Check if array is nested (not a simple list).
	 *
	 * @param array $array Array to check.
	 * @return bool
	 */
	private function is_nested_array( $array ) {
		// Check if it's a list of items.
		if ( isset( $array[0] ) && is_array( $array[0] ) ) {
			return true;
		}

		// Check for associative array.
		foreach ( $array as $key => $value ) {
			if ( is_string( $key ) && is_array( $value ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Static method to process template quickly.
	 *
	 * @param string $template Template text.
	 * @param array  $data     Data array.
	 * @return string Processed template.
	 */
	public static function render( $template, $data = array() ) {
		$engine = new self( $template, $data );
		return $engine->process();
	}

	/**
	 * Get placeholder usage examples.
	 *
	 * @return array Common placeholder examples.
	 */
	public static function get_placeholder_examples() {
		return array(
			'{order_id}'           => __( 'Order ID', 'sms-gate' ),
			'{order_number}'       => __( 'Order Number', 'sms-gate' ),
			'{customer_name}'      => __( 'Customer Full Name', 'sms-gate' ),
			'{first_name}'         => __( 'Customer First Name', 'sms-gate' ),
			'{last_name}'          => __( 'Customer Last Name', 'sms-gate' ),
			'{email}'              => __( 'Customer Email', 'sms-gate' ),
			'{phone}'              => __( 'Customer Phone', 'sms-gate' ),
			'{status}'             => __( 'Order Status (slug)', 'sms-gate' ),
			'{status_label}'       => __( 'Order Status (label)', 'sms-gate' ),
			'{total}'              => __( 'Order Total (number)', 'sms-gate' ),
			'{total_formatted}'    => __( 'Order Total (formatted)', 'sms-gate' ),
			'{currency}'           => __( 'Currency Code', 'sms-gate' ),
			'{currency_symbol}'    => __( 'Currency Symbol', 'sms-gate' ),
			'{payment_method}'     => __( 'Payment Method', 'sms-gate' ),
			'{shipping_method}'    => __( 'Shipping Method(s)', 'sms-gate' ),
			'{shipping_total}'     => __( 'Shipping Total', 'sms-gate' ),
			'{tax_total}'          => __( 'Tax Total', 'sms-gate' ),
			'{discount_total}'     => __( 'Discount Total', 'sms-gate' ),
			'{site_name}'          => __( 'Site Name', 'sms-gate' ),
			'{site_url}'           => __( 'Site URL', 'sms-gate' ),
			'{date}'               => __( 'Current Date', 'sms-gate' ),
			'{time}'               => __( 'Current Time', 'sms-gate' ),
			'{datetime}'           => __( 'Current Date & Time', 'sms-gate' ),
			'{billing.city}'       => __( 'Billing City', 'sms-gate' ),
			'{shipping.city}'      => __( 'Shipping City', 'sms-gate' ),
		);
	}

	/**
	 * Get system variables that are always available.
	 *
	 * @return array System variables.
	 */
	private function get_system_variables() {
		return array(
			'site_name' => get_bloginfo( 'name' ),
			'site_url'  => home_url(),
			'date'      => current_time( 'Y-m-d' ),
			'time'      => current_time( 'H:i:s' ),
			'datetime'  => current_time( 'Y-m-d H:i:s' ),
			'currency_symbol' => function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '',
		);
	}

	/**
	 * Merge data with system variables.
	 *
	 * @param array $data Data array.
	 * @return array Merged data.
	 */
	private function merge_with_system_variables( $data ) {
		$system_vars = $this->get_system_variables();
		return array_merge( $system_vars, $data );
	}
}