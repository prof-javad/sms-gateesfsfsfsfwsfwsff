<?php
/**
 * Admin settings template.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = $settings ?? new SMSGate_Settings();
$option_group = $settings->get_option_group();
?>

<div class="wrap">
	<h1><?php esc_html_e( 'SMS Gate Settings', 'sms-gate' ); ?></h1>

	<form method="post" action="options.php">
		<?php
		settings_fields( $option_group );
		do_settings_sections( 'sms-gate' );
		submit_button();
		?>
	</form>
</div>