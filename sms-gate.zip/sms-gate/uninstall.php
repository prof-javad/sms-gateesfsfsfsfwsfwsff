<?php
/**
 * Uninstall handler.
 *
 * @package SMSGate
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Delete plugin options.
delete_option( 'smsgate_username' );
delete_option( 'smsgate_password' );
delete_option( 'smsgate_device' );
delete_option( 'smsgate_settings' );

// Delete any other options.
global $wpdb;
$wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE 'smsgate_%'" );

// Drop the logs table.
$table_name = $wpdb->prefix . 'smsgate_logs';
$wpdb->query( "DROP TABLE IF EXISTS $table_name" );