<?php
/**
 * Admin functionality.
 *
 * @package SMSGate
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SMSGate_Admin
 */
class SMSGate_Admin {

	/**
	 * Settings instance.
	 *
	 * @var SMSGate_Settings
	 */
	private $settings;

	/**
	 * SMS Service instance.
	 *
	 * @var SMSGate_SMS_Service
	 */
	private $sms_service;

	/**
	 * Constructor.
	 *
	 * @param SMSGate_Settings    $settings Settings instance.
	 * @param SMSGate_SMS_Service $sms_service SMS service instance.
	 */
	public function __construct( $settings, $sms_service ) {
		$this->settings    = $settings;
		$this->sms_service = $sms_service;

		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Add admin menu.
	 */
	public function add_menu() {
		add_options_page(
			__( 'SMS Gate', 'sms-gate' ),
			__( 'SMS Gate', 'sms-gate' ),
			'manage_options',
			'sms-gate',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting(
			$this->settings->get_option_group(),
			SMSGate_Settings::OPTION_NAME,
			array( $this, 'sanitize_settings' )
		);

		// Register sections.
		$this->register_sections();
	}

	/**
	 * Register settings sections and fields.
	 */
	private function register_sections() {
		$sections = $this->settings->get_sections();

		foreach ( $sections as $id => $title ) {
			add_settings_section(
				$id,
				$title,
				array( $this, 'render_section_' . $id ),
				'sms-gate'
			);

			$this->register_fields( $id );
		}
	}

	/**
	 * Register fields for a section.
	 *
	 * @param string $section Section ID.
	 */
	private function register_fields( $section ) {
		$fields = $this->get_fields_for_section( $section );

		foreach ( $fields as $field ) {
			add_settings_field(
				$field['id'],
				$field['title'],
				array( $this, 'render_field_' . $field['type'] ),
				'sms-gate',
				$section,
				$field
			);
		}
	}

	/**
	 * Get fields for a section.
	 *
	 * @param string $section Section ID.
	 * @return array
	 */
	private function get_fields_for_section( $section ) {
		$fields = array();

		switch ( $section ) {
			case 'general':
				$fields = array(
					array(
						'id'          => 'api_url',
						'title'       => __( 'API URL', 'sms-gate' ),
						'type'        => 'text',
						'description' => __( 'SMS-Gate API endpoint URL', 'sms-gate' ),
						'required'    => true,
					),
					array(
						'id'          => 'api_key',
						'title'       => __( 'API Key', 'sms-gate' ),
						'type'        => 'password',
						'description' => __( 'Your API key for authentication', 'sms-gate' ),
						'required'    => true,
					),
					array(
						'id'          => 'sender_number',
						'title'       => __( 'Sender Number', 'sms-gate' ),
						'type'        => 'text',
						'description' => __( 'Sender phone number (e.g., +989123456789)', 'sms-gate' ),
						'required'    => true,
					),
					array(
						'id'          => 'manager_number',
						'title'       => __( 'Manager Number', 'sms-gate' ),
						'type'        => 'text',
						'description' => __( 'Manager phone number for notifications', 'sms-gate' ),
						'required'    => false,
					),
					array(
						'id'          => 'timeout',
						'title'       => __( 'Timeout', 'sms-gate' ),
						'type'        => 'number',
						'description' => __( 'Request timeout in seconds (default: 30)', 'sms-gate' ),
						'required'    => false,
						'min'         => 5,
						'max'         => 120,
					),
				);
				break;

			case 'order_status':
				$statuses = array(
					'new_order'   => __( 'New Order', 'sms-gate' ),
					'processing'  => __( 'Processing', 'sms-gate' ),
					'completed'   => __( 'Completed', 'sms-gate' ),
					'cancelled'   => __( 'Cancelled', 'sms-gate' ),
				);

				foreach ( $statuses as $key => $title ) {
					$fields[] = array(
						'id'          => 'enable_' . $key,
						'title'       => $title,
						'type'        => 'checkbox',
						'description' => sprintf( __( 'Enable SMS for %s', 'sms-gate' ), $title ),
						'required'    => false,
					);
				}
				break;

			case 'templates':
				$statuses = array(
					'new_order'   => __( 'New Order Template', 'sms-gate' ),
					'processing'  => __( 'Processing Template', 'sms-gate' ),
					'completed'   => __( 'Completed Template', 'sms-gate' ),
					'cancelled'   => __( 'Cancelled Template', 'sms-gate' ),
				);

				foreach ( $statuses as $key => $title ) {
					$fields[] = array(
						'id'          => 'template_' . $key,
						'title'       => $title,
						'type'        => 'textarea',
						'description' => __( 'Available placeholders: {order_id}, {customer_name}, {order_total}', 'sms-gate' ),
						'required'    => false,
						'rows'        => 3,
					);
				}
				break;
		}

		return $fields;
	}

	/**
	 * Render section description.
	 *
	 * @param array $args Section arguments.
	 */
	public function render_section_general( $args ) {
		?>
		<p><?php esc_html_e( 'Configure general SMS-Gate settings.', 'sms-gate' ); ?></p>
		<?php
	}

	/**
	 * Render section description.
	 *
	 * @param array $args Section arguments.
	 */
	public function render_section_order_status( $args ) {
		?>
		<p><?php esc_html_e( 'Enable or disable SMS notifications for each order status.', 'sms-gate' ); ?></p>
		<?php
	}

	/**
	 * Render section description.
	 *
	 * @param array $args Section arguments.
	 */
	public function render_section_templates( $args ) {
		?>
		<p><?php esc_html_e( 'Customize SMS templates for each order status.', 'sms-gate' ); ?></p>
		<?php
	}

	/**
	 * Render text field.
	 *
	 * @param array $field Field arguments.
	 */
	public function render_field_text( $field ) {
		$value = $this->settings->get( $field['id'] );
		$class = isset( $field['required'] ) && $field['required'] ? 'regular-text required' : 'regular-text';
		?>
		<input
			type="text"
			id="<?php echo esc_attr( 'smsgate_' . $field['id'] ); ?>"
			class="<?php echo esc_attr( $class ); ?>"
			name="<?php echo esc_attr( SMSGate_Settings::OPTION_NAME . '[' . $field['id'] . ']' ); ?>"
			value="<?php echo esc_attr( $value ); ?>"
		>
		<?php if ( ! empty( $field['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render password field.
	 *
	 * @param array $field Field arguments.
	 */
	public function render_field_password( $field ) {
		$value = $this->settings->get( $field['id'] );
		$class = isset( $field['required'] ) && $field['required'] ? 'regular-text required' : 'regular-text';
		?>
		<input
			type="password"
			id="<?php echo esc_attr( 'smsgate_' . $field['id'] ); ?>"
			class="<?php echo esc_attr( $class ); ?>"
			name="<?php echo esc_attr( SMSGate_Settings::OPTION_NAME . '[' . $field['id'] . ']' ); ?>"
			value="<?php echo esc_attr( $value ); ?>"
		>
		<?php if ( ! empty( $field['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render number field.
	 *
	 * @param array $field Field arguments.
	 */
	public function render_field_number( $field ) {
		$value = $this->settings->get( $field['id'] );
		$min   = isset( $field['min'] ) ? $field['min'] : '';
		$max   = isset( $field['max'] ) ? $field['max'] : '';
		?>
		<input
			type="number"
			id="<?php echo esc_attr( 'smsgate_' . $field['id'] ); ?>"
			class="small-text"
			name="<?php echo esc_attr( SMSGate_Settings::OPTION_NAME . '[' . $field['id'] . ']' ); ?>"
			value="<?php echo esc_attr( $value ); ?>"
			<?php if ( ! empty( $min ) ) : ?>
				min="<?php echo esc_attr( $min ); ?>"
			<?php endif; ?>
			<?php if ( ! empty( $max ) ) : ?>
				max="<?php echo esc_attr( $max ); ?>"
			<?php endif; ?>
		>
		<?php if ( ! empty( $field['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render checkbox field.
	 *
	 * @param array $field Field arguments.
	 */
	public function render_field_checkbox( $field ) {
		$value = $this->settings->get( $field['id'] );
		?>
		<label>
			<input
				type="checkbox"
				id="<?php echo esc_attr( 'smsgate_' . $field['id'] ); ?>"
				name="<?php echo esc_attr( SMSGate_Settings::OPTION_NAME . '[' . $field['id'] . ']' ); ?>"
				value="yes"
				<?php checked( 'yes', $value ); ?>
			>
			<?php echo esc_html( $field['description'] ); ?>
		</label>
		<?php
	}

	/**
	 * Render textarea field.
	 *
	 * @param array $field Field arguments.
	 */
	public function render_field_textarea( $field ) {
		$value = $this->settings->get( $field['id'] );
		$rows  = isset( $field['rows'] ) ? $field['rows'] : 5;
		?>
		<textarea
			id="<?php echo esc_attr( 'smsgate_' . $field['id'] ); ?>"
			class="large-text"
			name="<?php echo esc_attr( SMSGate_Settings::OPTION_NAME . '[' . $field['id'] . ']' ); ?>"
			rows="<?php echo esc_attr( $rows ); ?>"
		><?php echo esc_textarea( $value ); ?></textarea>
		<?php if ( ! empty( $field['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Input data.
	 * @return array
	 */
	public function sanitize_settings( $input ) {
		$output = array();
		$defaults = $this->settings->get_defaults();

		foreach ( $defaults as $key => $default_value ) {
			if ( isset( $input[ $key ] ) ) {
				$output[ $key ] = $this->sanitize_field( $key, $input[ $key ] );
			} else {
				// For checkboxes, default to 'no' if not present.
				if ( strpos( $key, 'enable_' ) === 0 ) {
					$output[ $key ] = 'no';
				} else {
					$output[ $key ] = $default_value;
				}
			}
		}

		return $output;
	}

	/**
	 * Sanitize a single field.
	 *
	 * @param string $key Field key.
	 * @param mixed  $value Field value.
	 * @return mixed
	 */
	private function sanitize_field( $key, $value ) {
		switch ( $key ) {
			case 'api_url':
				return esc_url_raw( $value );

			case 'api_key':
				return sanitize_text_field( $value );

			case 'sender_number':
			case 'manager_number':
				return sanitize_text_field( $value );

			case 'timeout':
				return absint( $value );

			case 'template_new_order':
			case 'template_processing':
			case 'template_completed':
			case 'template_cancelled':
				return wp_kses_post( $value );

			default:
				if ( strpos( $key, 'enable_' ) === 0 ) {
					return 'yes' === $value ? 'yes' : 'no';
				}
				return sanitize_text_field( $value );
		}
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current page hook.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'settings_page_sms-gate' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'smsgate-admin',
			SMSGATE_URL . 'assets/css/admin.css',
			array(),
			SMSGATE_VERSION
		);

		wp_enqueue_script(
			'smsgate-admin',
			SMSGATE_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			SMSGATE_VERSION,
			true
		);
	}

	/**
	 * Render admin page.
	 */
	public function render_page() {
		// Load the admin settings template.
		$template_file = SMSGATE_PATH . 'templates/admin-settings.php';

		if ( ! file_exists( $template_file ) ) {
			return;
		}

		$args = array(
			'settings' => $this->settings,
		);

		extract( $args, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract

		include $template_file;
	}
}